﻿namespace BattleField_XMLCreate
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddMonsterButton = new System.Windows.Forms.Button();
            this.DeleteMonsterButton = new System.Windows.Forms.Button();
            this.MonsterListView = new System.Windows.Forms.ListView();
            this.FieldNameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.MonsterNameTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.MonsterHpTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MonsterAtkTextBox = new System.Windows.Forms.TextBox();
            this.DeleteField = new System.Windows.Forms.Button();
            this.CreateField = new System.Windows.Forms.Button();
            this.FieldListView = new System.Windows.Forms.ListView();
            this.RequireLevelTextBox = new System.Windows.Forms.TextBox();
            this.LimitLevel = new System.Windows.Forms.Label();
            this.SelectFieldLabel = new System.Windows.Forms.Label();
            this.SaveCurrentFieldData = new System.Windows.Forms.Button();
            this.FieldLList = new System.Windows.Forms.Label();
            this.LoadProgressData = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.MonsterAtkTypeComboBox = new System.Windows.Forms.ComboBox();
            this.MonsterGradeComboBox = new System.Windows.Forms.ComboBox();
            this.MonsterPrefabNameTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AddMonsterButton
            // 
            this.AddMonsterButton.Location = new System.Drawing.Point(218, 475);
            this.AddMonsterButton.Name = "AddMonsterButton";
            this.AddMonsterButton.Size = new System.Drawing.Size(105, 44);
            this.AddMonsterButton.TabIndex = 16;
            this.AddMonsterButton.Text = "AddElement";
            this.AddMonsterButton.UseVisualStyleBackColor = true;
            this.AddMonsterButton.Click += new System.EventHandler(this.AddMonsterButton_Click);
            // 
            // DeleteMonsterButton
            // 
            this.DeleteMonsterButton.Location = new System.Drawing.Point(329, 475);
            this.DeleteMonsterButton.Name = "DeleteMonsterButton";
            this.DeleteMonsterButton.Size = new System.Drawing.Size(105, 44);
            this.DeleteMonsterButton.TabIndex = 17;
            this.DeleteMonsterButton.Text = "DeleteElement";
            this.DeleteMonsterButton.UseVisualStyleBackColor = true;
            this.DeleteMonsterButton.Click += new System.EventHandler(this.DeleteMonsterButton_Click);
            // 
            // MonsterListView
            // 
            this.MonsterListView.Location = new System.Drawing.Point(21, 205);
            this.MonsterListView.Name = "MonsterListView";
            this.MonsterListView.Size = new System.Drawing.Size(404, 128);
            this.MonsterListView.TabIndex = 5;
            this.MonsterListView.UseCompatibleStateImageBehavior = false;
            this.MonsterListView.SelectedIndexChanged += new System.EventHandler(this.MonsterListView_SelectedIndexChanged);
            // 
            // FieldNameTextBox
            // 
            this.FieldNameTextBox.Location = new System.Drawing.Point(274, 24);
            this.FieldNameTextBox.Name = "FieldNameTextBox";
            this.FieldNameTextBox.Size = new System.Drawing.Size(136, 21);
            this.FieldNameTextBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(202, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "FieldName :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 360);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "Name :";
            // 
            // MonsterNameTextBox
            // 
            this.MonsterNameTextBox.Location = new System.Drawing.Point(60, 352);
            this.MonsterNameTextBox.Name = "MonsterNameTextBox";
            this.MonsterNameTextBox.Size = new System.Drawing.Size(136, 21);
            this.MonsterNameTextBox.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 399);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 11;
            this.label3.Text = "HP :";
            // 
            // MonsterHpTextBox
            // 
            this.MonsterHpTextBox.Location = new System.Drawing.Point(60, 393);
            this.MonsterHpTextBox.Name = "MonsterHpTextBox";
            this.MonsterHpTextBox.Size = new System.Drawing.Size(136, 21);
            this.MonsterHpTextBox.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 440);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 12);
            this.label4.TabIndex = 13;
            this.label4.Text = "ATK :";
            // 
            // MonsterAtkTextBox
            // 
            this.MonsterAtkTextBox.Location = new System.Drawing.Point(60, 437);
            this.MonsterAtkTextBox.Name = "MonsterAtkTextBox";
            this.MonsterAtkTextBox.Size = new System.Drawing.Size(136, 21);
            this.MonsterAtkTextBox.TabIndex = 12;
            // 
            // DeleteField
            // 
            this.DeleteField.Location = new System.Drawing.Point(308, 99);
            this.DeleteField.Name = "DeleteField";
            this.DeleteField.Size = new System.Drawing.Size(105, 44);
            this.DeleteField.TabIndex = 9;
            this.DeleteField.Text = "DeleteField";
            this.DeleteField.UseVisualStyleBackColor = true;
            this.DeleteField.Click += new System.EventHandler(this.DeleteField_Click);
            // 
            // CreateField
            // 
            this.CreateField.Location = new System.Drawing.Point(205, 99);
            this.CreateField.Name = "CreateField";
            this.CreateField.Size = new System.Drawing.Size(105, 44);
            this.CreateField.TabIndex = 8;
            this.CreateField.Text = "AddField";
            this.CreateField.UseVisualStyleBackColor = true;
            this.CreateField.Click += new System.EventHandler(this.CreateField_Click);
            // 
            // FieldListView
            // 
            this.FieldListView.Location = new System.Drawing.Point(21, 38);
            this.FieldListView.Name = "FieldListView";
            this.FieldListView.Size = new System.Drawing.Size(175, 131);
            this.FieldListView.TabIndex = 16;
            this.FieldListView.UseCompatibleStateImageBehavior = false;
            this.FieldListView.SelectedIndexChanged += new System.EventHandler(this.FieldListView_SelectedIndexChanged);
            // 
            // RequireLevelTextBox
            // 
            this.RequireLevelTextBox.Location = new System.Drawing.Point(274, 60);
            this.RequireLevelTextBox.Name = "RequireLevelTextBox";
            this.RequireLevelTextBox.Size = new System.Drawing.Size(136, 21);
            this.RequireLevelTextBox.TabIndex = 7;
            // 
            // LimitLevel
            // 
            this.LimitLevel.AutoSize = true;
            this.LimitLevel.Location = new System.Drawing.Point(202, 63);
            this.LimitLevel.Name = "LimitLevel";
            this.LimitLevel.Size = new System.Drawing.Size(74, 12);
            this.LimitLevel.TabIndex = 18;
            this.LimitLevel.Text = "LimitLevel : ";
            // 
            // SelectFieldLabel
            // 
            this.SelectFieldLabel.AutoSize = true;
            this.SelectFieldLabel.Location = new System.Drawing.Point(177, 190);
            this.SelectFieldLabel.Name = "SelectFieldLabel";
            this.SelectFieldLabel.Size = new System.Drawing.Size(98, 12);
            this.SelectFieldLabel.TabIndex = 19;
            this.SelectFieldLabel.Text = "SelectFieldLabel";
            // 
            // SaveCurrentFieldData
            // 
            this.SaveCurrentFieldData.Location = new System.Drawing.Point(72, 536);
            this.SaveCurrentFieldData.Name = "SaveCurrentFieldData";
            this.SaveCurrentFieldData.Size = new System.Drawing.Size(175, 50);
            this.SaveCurrentFieldData.TabIndex = 18;
            this.SaveCurrentFieldData.Text = "SaveCurrentFieldData";
            this.SaveCurrentFieldData.UseVisualStyleBackColor = true;
            this.SaveCurrentFieldData.Click += new System.EventHandler(this.SaveCurrentFieldData_Click);
            // 
            // FieldLList
            // 
            this.FieldLList.AutoSize = true;
            this.FieldLList.Location = new System.Drawing.Point(81, 23);
            this.FieldLList.Name = "FieldLList";
            this.FieldLList.Size = new System.Drawing.Size(59, 12);
            this.FieldLList.TabIndex = 21;
            this.FieldLList.Text = "FieldLList";
            // 
            // LoadProgressData
            // 
            this.LoadProgressData.Location = new System.Drawing.Point(259, 536);
            this.LoadProgressData.Name = "LoadProgressData";
            this.LoadProgressData.Size = new System.Drawing.Size(175, 50);
            this.LoadProgressData.TabIndex = 19;
            this.LoadProgressData.Text = "LoadProgressData";
            this.LoadProgressData.UseVisualStyleBackColor = true;
            this.LoadProgressData.Click += new System.EventHandler(this.LoadProgressData_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(226, 396);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 23;
            this.label5.Text = "AtkType :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(234, 437);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 12);
            this.label6.TabIndex = 25;
            this.label6.Text = "Grade : ";
            // 
            // MonsterAtkTypeComboBox
            // 
            this.MonsterAtkTypeComboBox.FormattingEnabled = true;
            this.MonsterAtkTypeComboBox.Location = new System.Drawing.Point(293, 396);
            this.MonsterAtkTypeComboBox.Name = "MonsterAtkTypeComboBox";
            this.MonsterAtkTypeComboBox.Size = new System.Drawing.Size(132, 20);
            this.MonsterAtkTypeComboBox.TabIndex = 14;
            // 
            // MonsterGradeComboBox
            // 
            this.MonsterGradeComboBox.FormattingEnabled = true;
            this.MonsterGradeComboBox.Location = new System.Drawing.Point(293, 435);
            this.MonsterGradeComboBox.Name = "MonsterGradeComboBox";
            this.MonsterGradeComboBox.Size = new System.Drawing.Size(132, 20);
            this.MonsterGradeComboBox.TabIndex = 15;
            // 
            // MonsterPrefabNameTextBox
            // 
            this.MonsterPrefabNameTextBox.Location = new System.Drawing.Point(289, 351);
            this.MonsterPrefabNameTextBox.Name = "MonsterPrefabNameTextBox";
            this.MonsterPrefabNameTextBox.Size = new System.Drawing.Size(136, 21);
            this.MonsterPrefabNameTextBox.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(202, 354);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 12);
            this.label7.TabIndex = 26;
            this.label7.Text = "PrefabName :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 596);
            this.Controls.Add(this.MonsterPrefabNameTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.MonsterGradeComboBox);
            this.Controls.Add(this.MonsterAtkTypeComboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.LoadProgressData);
            this.Controls.Add(this.FieldLList);
            this.Controls.Add(this.SaveCurrentFieldData);
            this.Controls.Add(this.SelectFieldLabel);
            this.Controls.Add(this.LimitLevel);
            this.Controls.Add(this.RequireLevelTextBox);
            this.Controls.Add(this.FieldListView);
            this.Controls.Add(this.DeleteField);
            this.Controls.Add(this.CreateField);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.MonsterAtkTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MonsterHpTextBox);
            this.Controls.Add(this.MonsterNameTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FieldNameTextBox);
            this.Controls.Add(this.MonsterListView);
            this.Controls.Add(this.DeleteMonsterButton);
            this.Controls.Add(this.AddMonsterButton);
            this.Name = "Form1";
            this.Text = "BattleField_XMLCreate";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddMonsterButton;
        private System.Windows.Forms.Button DeleteMonsterButton;
        private System.Windows.Forms.ListView MonsterListView;
        private System.Windows.Forms.TextBox FieldNameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox MonsterNameTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox MonsterHpTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox MonsterAtkTextBox;
        private System.Windows.Forms.Button DeleteField;
        private System.Windows.Forms.Button CreateField;
        private System.Windows.Forms.ListView FieldListView;
        private System.Windows.Forms.TextBox RequireLevelTextBox;
        private System.Windows.Forms.Label LimitLevel;
        private System.Windows.Forms.Label SelectFieldLabel;
        private System.Windows.Forms.Button SaveCurrentFieldData;
        private System.Windows.Forms.Label FieldLList;
        private System.Windows.Forms.Button LoadProgressData;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox MonsterAtkTypeComboBox;
        private System.Windows.Forms.ComboBox MonsterGradeComboBox;
        private System.Windows.Forms.TextBox MonsterPrefabNameTextBox;
        private System.Windows.Forms.Label label7;
    }
}

