﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enums
{
    public enum MONSTERGRADEID
    {
        GRADE_ERROR = -1,
        GRADE_NORMAL = 0,
        GRADE_ELITE,
        GRADE_BOSS,
        GRADE_LEGEND,
        GRADE_GOD,
        GRADE_HIDDEN,
        GRADE_MAX,
    }

    public enum ATKTYPEID
    {
        ATT_ERROR = -1,
        ATT_MELEE = 0,
        ATT_RANGE,
        ATT_MAGIC,
        ATT_SUMMON,
        ATT_MAX,
    };
}
