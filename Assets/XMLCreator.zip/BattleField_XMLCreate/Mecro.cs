﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BattleField_XMLCreate
{
    class Mecro
    {
        public static string SeperateFileName(string FilePath)
        {
            //index 0 - FullPath, index 1 - FileName
            int LastIndex = FilePath.LastIndexOf("\\") + 1;
            string FileName = FilePath.Substring(LastIndex);

            return FileName;
        }

        /// <summary>
        /// bool true = OK bool false = cancel
        /// </summary>
        public static bool AppearOKCancelButton(string message, string caption)
        {
            MessageBoxButtons buttons = MessageBoxButtons.OKCancel;
            // Show message box
            var result = MessageBox.Show(message, caption, buttons);
            if (result == DialogResult.Cancel)
                return false;
            return true;
        }
    }
}
