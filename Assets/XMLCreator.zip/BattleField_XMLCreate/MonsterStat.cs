﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Enums;

namespace BattleField_XMLCreate
{
    public class MonsterStat
    {
        public MonsterStat() { }
        public MonsterStat(string Name, string Hp, string Atk,
            string PrefabName, string AtkType, string MonsterGrade)
        {
            SetStatInfo(Name, Hp, Atk, PrefabName, AtkType, MonsterGrade);
        }

        private string _MonsterName;
        public string MonsterName
        {
            get { return _MonsterName; }
            set { _MonsterName = value; }
        }

        private int _MonsterHp;
        public int MonsterHp
        {
            get { return _MonsterHp; }
            set { _MonsterHp = value; }
        }

        private int _MonsterAtk;
        public int MonsterAtk
        {
            get { return _MonsterAtk; }
            set { _MonsterAtk = value; }
        }

        private string _MonsterPrefabName;
        public string MonsterPrefabName
        {
            get { return _MonsterPrefabName; }
            set { _MonsterPrefabName = value; }
        }


        private ATKTYPEID _MonsterATkType;
        public ATKTYPEID MonsterAtkType
        {
            get { return _MonsterATkType; }
            set { _MonsterATkType = value; }
        }

        private MONSTERGRADEID _MonsterGradeType;
        public MONSTERGRADEID MonsterGradeType
        {
            get { return _MonsterGradeType; }
            set { _MonsterGradeType = value; }
        }

        //변수 생성했으니 해당 함수에 관한 내용 추가할것!

        public void SetStatInfo(string Hp, string Atk)
        {
            try
            {
                _MonsterHp = Int32.Parse(Hp);
                _MonsterAtk = Int32.Parse(Atk);
            }
            catch (FormatException e)
            {
                MessageBox.Show(e.Message + "\n" + "HP, ATK에는 숫자만 입력해주세요");
                return;
            }
        }
        public void SetStatInfo(string Name, string Hp, string Atk,
            string PrefabName, string AtkType, string MonsterGrade)
        {
            try
            {
                _MonsterName = Name;
                _MonsterHp = Int32.Parse(Hp);
                _MonsterAtk = Int32.Parse(Atk);
                _MonsterATkType = ConvertStringToAtkType(AtkType);
                _MonsterGradeType = ConvertStringToMonsterGrade(MonsterGrade);
                _MonsterPrefabName = PrefabName;

            }
            catch (FormatException e)
            {
                MessageBox.Show(e.Message + "\n" + "HP, ATK에는 숫자만 입력해주세요");
                return;
            }
        }

        public static ATKTYPEID ConvertStringToAtkType(string IDName)
        {
            ATKTYPEID resultid = (ATKTYPEID)0;

            switch (IDName)
            {
                case "ATT_MELEE":
                    resultid = (ATKTYPEID)0;
                    break;

                case "ATT_RANGE":
                    resultid = (ATKTYPEID)1;
                    break;

                case "ATT_MAGIC":
                    resultid = (ATKTYPEID)2;
                    break;

                case "ATT_SUMMON":
                    resultid = (ATKTYPEID)3;
                    break;

                default:
                    MessageBox.Show("해당되는 원소의 인자값이 형성되지 않았습니다.");
                    return ATKTYPEID.ATT_ERROR;
            }

            return resultid;
        }
        public static MONSTERGRADEID ConvertStringToMonsterGrade(string IDName)
        {
            MONSTERGRADEID resultid = (MONSTERGRADEID)0;

            switch (IDName)
            {
                case "GRADE_NORMAL":
                    resultid = (MONSTERGRADEID)0;
                    break;

                case "GRADE_ELITE":
                    resultid = (MONSTERGRADEID)1;
                    break;

                case "GRADE_BOSS":
                    resultid = (MONSTERGRADEID)2;
                    break;

                case "GRADE_LEGEND":
                    resultid = (MONSTERGRADEID)3;
                    break;

                case "GRADE_GOD":
                    resultid = (MONSTERGRADEID)4;
                    break;

                case "GRADE_HIDDEN":
                    resultid = (MONSTERGRADEID)5;
                    break;

                default:
                    MessageBox.Show("해당되는 원소의 객체값이 존재하지 않습니다.");
                    return MONSTERGRADEID.GRADE_ERROR;
            }

            return resultid;
        }

        public void WriteXML_MonsterElement(XmlTextWriter writer)
        {
            writer.WriteStartElement("Monster");

            writer.WriteStartElement("Monster_Name");
            writer.WriteString(_MonsterName);
            writer.WriteEndElement();

            writer.WriteStartElement("Monster_Hp");
            writer.WriteString(_MonsterHp.ToString());
            writer.WriteEndElement();

            writer.WriteStartElement("Monster_Atk");
            writer.WriteString(_MonsterAtk.ToString());
            writer.WriteEndElement();

            writer.WriteStartElement("Monster_PrefabName");
            writer.WriteString(_MonsterPrefabName);
            writer.WriteEndElement();

            writer.WriteStartElement("Monster_AtkType");
            writer.WriteString(_MonsterATkType.ToString());
            writer.WriteEndElement();

            writer.WriteStartElement("Monster_Grade");
            writer.WriteString(_MonsterGradeType.ToString());
            writer.WriteEndElement();

            writer.WriteEndElement();
        }
        public static MonsterStat LoadXML_MonsterElement(XmlNode node, out string MonName)
        {
            MonsterStat MonsterInfo = new MonsterStat();

            MonsterInfo._MonsterName = node.SelectSingleNode("Monster_Name").InnerText;
            MonsterInfo._MonsterHp = Int32.Parse(node.SelectSingleNode("Monster_Hp").InnerText);
            MonsterInfo._MonsterAtk = Int32.Parse(node.SelectSingleNode("Monster_Atk").InnerText);
            MonsterInfo._MonsterPrefabName = node.SelectSingleNode("Monster_PrefabName").InnerText;
            MonsterInfo._MonsterATkType = ConvertStringToAtkType(node.SelectSingleNode("Monster_AtkType").InnerText);
            MonsterInfo._MonsterGradeType = ConvertStringToMonsterGrade(node.SelectSingleNode("Monster_Grade").InnerText);

            MonName = MonsterInfo._MonsterName;

            return MonsterInfo;
        }
    }
}
