﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Xml;
using Enums;

namespace BattleField_XMLCreate
{
    public partial class Form1 : Form
    {
        private const int ElementCount = 6;

        public static Dictionary<string, BattleField_Container> _FieldContainer;
        private BattleField_Container SelectedField;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _FieldContainer
                = new Dictionary<string, BattleField_Container>();

            //FieldListView Setting
            FieldListView.View = View.Details;
            FieldListView.GridLines = true;
            FieldListView.FullRowSelect = true;

            //Add column header
            FieldListView.Columns.Add("FieldName", 120);
            FieldListView.Columns.Add("Level", 55);

            //MonsterListView Setting
            MonsterListView.View = View.Details;
            MonsterListView.GridLines = true;
            MonsterListView.FullRowSelect = true;

            //Add column header
            MonsterListView.Columns.Add("Name", 150);
            MonsterListView.Columns.Add("Hp", 30);
            MonsterListView.Columns.Add("Atk", 30);
            MonsterListView.Columns.Add("PrefabName", 60);
            MonsterListView.Columns.Add("AtkType", 65);
            MonsterListView.Columns.Add("Mon_Grade", 65);
            
            //ComboBox Item Add
            for (int i = 0; i < (int)MONSTERGRADEID.GRADE_MAX; ++i)
                MonsterGradeComboBox.Items.Add(((MONSTERGRADEID)i).ToString());
            MonsterGradeComboBox.SelectedIndex = 0;

            for (int i = 0; i < (int)ATKTYPEID.ATT_MAX; ++i)
                MonsterAtkTypeComboBox.Items.Add(((ATKTYPEID)i).ToString());
            MonsterAtkTypeComboBox.SelectedIndex = 0;
        }

        private void ApplyLoadedData()
        {
            ListViewItem item;
            for (int i = 0; i < _FieldContainer.Count; ++i)
            {
                item = new ListViewItem( _FieldContainer.Keys.ToList()[i] );
                item.SubItems.Add(_FieldContainer.Values.ToList()[i].RequireLevel.ToString());
                FieldListView.Items.Add(item);
            }
        }

        private void FieldListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (FieldListView.SelectedItems.Count != 0)
            {
                FieldNameTextBox.Text = FieldListView.SelectedItems[0].Text;
                RequireLevelTextBox.Text = FieldListView.SelectedItems[0].SubItems[1].Text;

                MonsterListView.Items.Clear();
                string SelectedKey = FieldListView.SelectedItems[0].SubItems[0].Text;
                SelectFieldLabel.Text = SelectedKey + "_MonsterList";

                SelectedField = _FieldContainer[SelectedKey];

                if (SelectedField == null)
                {
                    MessageBox.Show(SelectedField.ToString() + "Object is Null");
                    return;
                }

                foreach (KeyValuePair<string, MonsterStat> Stat in
                    SelectedField.MonsterStatContainer)
                {
                    string[] Elements = new string[6];
                    Elements[0] = Stat.Key;
                    Elements[1] = Stat.Value.MonsterHp.ToString();
                    Elements[2] = Stat.Value.MonsterAtk.ToString();
                    Elements[3] = Stat.Value.MonsterPrefabName.ToString();
                    Elements[4] = Stat.Value.MonsterAtkType.ToString();
                    Elements[5] = Stat.Value.MonsterGradeType.ToString();

                    ListViewItem item = new ListViewItem(Elements);
                    //item.SubItems
                    MonsterListView.Items.Add(item);
                }

                //MessageBox.Show(FieldListView.SelectedIndices[0].ToString());

            }
        }

        private void CreateField_Click(object sender, EventArgs e)
        {
            //모든 정보가 입력될때까지 갱신 중지
            FieldListView.BeginUpdate();

            //Add itemString in the listview
            string[] itemString = new string[2];

            //Add first item
            itemString[0] = FieldNameTextBox.Text;
            itemString[1] = RequireLevelTextBox.Text;

            try
            {
                int nCount = Int32.Parse(itemString[1]);
            }
            catch (FormatException exception)
            {
                MessageBox.Show(exception.Message + "\n" + "숫자만 입력하세요.");
                RequireLevelTextBox.Text = "";
                return;
            }

            //ListView Adding
            ListViewItem Finditem = FieldListView.FindItemWithText(FieldNameTextBox.Text);
            if (Finditem == null)
            { //존재하지 않을경우
              //BattleField_Container Add
                BattleField_Container Field = new BattleField_Container();
                Field.FieldName = itemString[0];
                Field.RequireLevel = int.Parse(itemString[1]);
                _FieldContainer.Add(itemString[0], Field);

                //itemList
                ListViewItem itm = new ListViewItem(itemString[0]);
                itm.SubItems.Add(itemString[1]);
                FieldListView.Items.Add(itm);
            }
            else
            { //존재할경우
                //BattleField_Container Find And Modify
                _FieldContainer[itemString[0]].RequireLevel = Int32.Parse(itemString[1]);

                //itemList
                FieldListView.Items.Remove(Finditem);
                Finditem.SubItems[1].Text = RequireLevelTextBox.Text;
                FieldListView.Items.Add(Finditem);
            }
            

            //성공적으로 정보가 입력되면 갱신
            FieldListView.EndUpdate();

            FieldNameTextBox.Text = "";
            RequireLevelTextBox.Text = "";
        }

        private void AddMonsterButton_Click(object sender, EventArgs e)
        {
            MonsterListView.BeginUpdate();

            try
            {
                if (SelectedField == null)
                {
                    MessageBox.Show(SelectedField.ToString() + "Object is Null\n" +
                        "필드를 선택하고 추가하세요.");
                }
            
            }
            catch(NullReferenceException Exception)
            {
                MessageBox.Show(Exception.Message + "\n" +
                        "필드를 선택하고 추가하세요.");
                MonsterListView.EndUpdate();
                return;
            }

            MonsterStat MonsterInfo;
            
            if (SelectedField.MonsterStatContainer.ContainsKey(MonsterNameTextBox.Text))
                //기존에 이름이 존재하는 경우
            {
                MonsterInfo = SelectedField.MonsterStatContainer[MonsterNameTextBox.Text];
                MonsterInfo.SetStatInfo(MonsterHpTextBox.Text, MonsterAtkTextBox.Text);

                ListViewItem Finditem = MonsterListView.FindItemWithText(MonsterNameTextBox.Text);
                MonsterListView.Items.Remove(Finditem);

                //갯수가 틀릴경우
                if (ElementCount != Finditem.SubItems.Count)
                {
                    ListViewItem Newitem = new ListViewItem(MonsterNameTextBox.Text);
                    Newitem.SubItems[1].Text = MonsterHpTextBox.Text;
                    Newitem.SubItems[2].Text = MonsterAtkTextBox.Text;
                    Newitem.SubItems[3].Text = MonsterPrefabNameTextBox.Text;
                    Newitem.SubItems[4].Text = MonsterAtkTypeComboBox.Text;
                    Newitem.SubItems[5].Text = MonsterGradeComboBox.Text;
                    MonsterListView.Items.Add(Newitem);
                }
                else
                {
                    Finditem.SubItems[1].Text = MonsterHpTextBox.Text;
                    Finditem.SubItems[2].Text = MonsterAtkTextBox.Text;
                    Finditem.SubItems[3].Text = MonsterPrefabNameTextBox.Text;
                    Finditem.SubItems[4].Text = MonsterAtkTypeComboBox.Text;
                    Finditem.SubItems[5].Text = MonsterGradeComboBox.Text;
                    MonsterListView.Items.Add(Finditem);
                }

            }
            else
            //이름이 존재하지 않는 경우
            {
                MonsterInfo = new MonsterStat(MonsterNameTextBox.Text,
                    MonsterHpTextBox.Text, MonsterAtkTextBox.Text,
                    MonsterPrefabNameTextBox.Text, 
                    MonsterAtkTypeComboBox.Text, MonsterGradeComboBox.Text);
                
                SelectedField.MonsterStatContainer.Add(MonsterNameTextBox.Text, MonsterInfo);

                ListViewItem item = new ListViewItem(MonsterNameTextBox.Text);
                item.SubItems.Add(MonsterHpTextBox.Text);
                item.SubItems.Add(MonsterAtkTextBox.Text);
                item.SubItems.Add(MonsterPrefabNameTextBox.Text);
                item.SubItems.Add(MonsterAtkTypeComboBox.Text);
                item.SubItems.Add(MonsterGradeComboBox.Text);

                MonsterListView.Items.Add(item);
            }

            //ListView Update
            MonsterListView.EndUpdate();
        }


        private void SaveCurrentFieldData_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.FileName = SelectedField.FieldName + ".xml";
            MessageBox.Show(dlg.FileName);
            //dlg.ShowDialog();

            SaveFieldConvertXMLFile(dlg.FileName);
        }

        private void SaveFieldConvertXMLFile(string FullPath)
        {
            string FileName = Mecro.SeperateFileName(FullPath);
            int Formatidx = FileName.LastIndexOf('.');
            string FileFormat = FileName.Substring(Formatidx + 1);

            if(FileFormat == null)
                FileName += ".xml";
            else if(FileFormat != "xml")
            {
                MessageBox.Show("Cannot Save File - Format Type is wrong");
                return;
            }

            string SaveFolderPath = "SavedFieldXml\\";
            string SaveFilePath = SaveFolderPath + FileName;

            XmlTextWriter writer = new XmlTextWriter(SaveFilePath, Encoding.UTF8);
            writer.WriteStartDocument(true);
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;

            SelectedField.WriteXML_BFContainer(writer);

            writer.WriteEndDocument();
            writer.Close();
        }

        private void LoadProgressData_Click(object sender, EventArgs e)
        {

            if (!Mecro.AppearOKCancelButton(
                "해당 기능을 실행하면 기존에 작업한 데이터를 모두 손실합니다. \n진행하시겠습니까?"
                ,"Warning"))
                return;

            FieldListView.Items.Clear();
            MonsterListView.Items.Clear();
            _FieldContainer.Clear();

            string[] filePaths = Directory.GetFiles("SavedFieldXml\\", "*.xml");
            foreach (string file in filePaths)
                CurrentDirectory.GetIntstance().LoadAllXml(file);
            ApplyLoadedData();
        }

        private void DeleteField_Click(object sender, EventArgs e)
        {
            if (!Mecro.AppearOKCancelButton(
               "기록된 XML의 필드 데이터와 하위 등록된 몬스터 정보를 삭제하시겠습니까?"
               ,"Warning"))
                return;

            if (FieldListView.SelectedItems.Count != 0)
            {
                FieldListView.BeginUpdate();
                MonsterListView.BeginUpdate();

                ListViewItem Deleteitem = FieldListView.SelectedItems[0];

                if(Deleteitem == null)
                {
                    MessageBox.Show("선택된 필드가 존재하지 않습니다");
                    FieldListView.EndUpdate();
                    MonsterListView.EndUpdate();
                    return;
                }

                //ListView Delete
                FieldListView.Items.Remove(Deleteitem);

                //Container Data Delete
                _FieldContainer.Remove(Deleteitem.Text);

                //XML Delete
                System.IO.File.Delete(Environment.CurrentDirectory +
                    "\\SavedFieldXml\\" + Deleteitem.Text + ".xml");

                MonsterListView.Items.Clear();

                FieldListView.EndUpdate();
                MonsterListView.EndUpdate();
            }
        }

        private void DeleteMonsterButton_Click(object sender, EventArgs e)
        {
            if (MonsterListView.SelectedItems.Count != 0)
            {
                MonsterListView.BeginUpdate();

                ListViewItem Deleteitem = MonsterListView.SelectedItems[0];

                if (Deleteitem == null)
                {
                    MessageBox.Show("선택된 아이템이 존재하지 않습니다");
                    return;
                }

                MonsterListView.Items.Remove(Deleteitem);
                SelectedField.MonsterStatContainer.Remove(Deleteitem.Text);

                MonsterListView.EndUpdate();
            }
        }

        private void MonsterListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (MonsterListView.SelectedItems.Count != 0)
            {
                MonsterAtkTypeComboBox.SelectedIndex = -1;
                MonsterGradeComboBox.SelectedIndex = -1;

                ListViewItem Selecteditem = MonsterListView.SelectedItems[0];

                MonsterNameTextBox.Text = Selecteditem.Text;
                MonsterHpTextBox.Text = Selecteditem.SubItems[1].Text;
                MonsterAtkTextBox.Text = Selecteditem.SubItems[2].Text;
                MonsterPrefabNameTextBox.Text = Selecteditem.SubItems[3].Text;
                
                MonsterAtkTypeComboBox.SelectedItem = Selecteditem.SubItems[4].Text;
                MonsterGradeComboBox.SelectedItem = Selecteditem.SubItems[5].Text;
            }
        }
    }
}
