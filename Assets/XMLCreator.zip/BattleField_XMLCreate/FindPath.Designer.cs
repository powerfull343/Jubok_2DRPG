﻿namespace BattleField_XMLCreate
{
    partial class FindPath
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OpenedFileListView = new System.Windows.Forms.ListView();
            this.OpenedFileLabel = new System.Windows.Forms.Label();
            this.DetailDirectory = new System.Windows.Forms.Button();
            this.LoadXML = new System.Windows.Forms.Button();
            this.SaveXML = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // OpenedFileListView
            // 
            this.OpenedFileListView.Location = new System.Drawing.Point(12, 41);
            this.OpenedFileListView.Name = "OpenedFileListView";
            this.OpenedFileListView.Size = new System.Drawing.Size(365, 294);
            this.OpenedFileListView.TabIndex = 0;
            this.OpenedFileListView.UseCompatibleStateImageBehavior = false;
            // 
            // OpenedFileLabel
            // 
            this.OpenedFileLabel.AutoSize = true;
            this.OpenedFileLabel.Location = new System.Drawing.Point(12, 26);
            this.OpenedFileLabel.Name = "OpenedFileLabel";
            this.OpenedFileLabel.Size = new System.Drawing.Size(69, 12);
            this.OpenedFileLabel.TabIndex = 1;
            this.OpenedFileLabel.Text = "OpenedFile";
            // 
            // DetailDirectory
            // 
            this.DetailDirectory.Location = new System.Drawing.Point(12, 341);
            this.DetailDirectory.Name = "DetailDirectory";
            this.DetailDirectory.Size = new System.Drawing.Size(89, 30);
            this.DetailDirectory.TabIndex = 2;
            this.DetailDirectory.Text = "Find...";
            this.DetailDirectory.UseVisualStyleBackColor = true;
            this.DetailDirectory.Click += new System.EventHandler(this.DetailDirectory_Click);
            // 
            // LoadXML
            // 
            this.LoadXML.Location = new System.Drawing.Point(275, 452);
            this.LoadXML.Name = "LoadXML";
            this.LoadXML.Size = new System.Drawing.Size(102, 57);
            this.LoadXML.TabIndex = 3;
            this.LoadXML.Text = "Load!";
            this.LoadXML.UseVisualStyleBackColor = true;
            this.LoadXML.Click += new System.EventHandler(this.LoadXML_Click);
            // 
            // SaveXML
            // 
            this.SaveXML.Location = new System.Drawing.Point(167, 452);
            this.SaveXML.Name = "SaveXML";
            this.SaveXML.Size = new System.Drawing.Size(102, 57);
            this.SaveXML.TabIndex = 4;
            this.SaveXML.Text = "Save!";
            this.SaveXML.UseVisualStyleBackColor = true;
            this.SaveXML.Click += new System.EventHandler(this.SaveXML_Click);
            // 
            // FindPath
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 521);
            this.Controls.Add(this.SaveXML);
            this.Controls.Add(this.LoadXML);
            this.Controls.Add(this.DetailDirectory);
            this.Controls.Add(this.OpenedFileLabel);
            this.Controls.Add(this.OpenedFileListView);
            this.Name = "FindPath";
            this.Text = "FindPath";
            this.Load += new System.EventHandler(this.FindPath_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView OpenedFileListView;
        private System.Windows.Forms.Label OpenedFileLabel;
        private System.Windows.Forms.Button DetailDirectory;
        private System.Windows.Forms.Button LoadXML;
        private System.Windows.Forms.Button SaveXML;
    }
}