﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Xml;

namespace BattleField_XMLCreate
{
    class CurrentDirectory
    {
        private static CurrentDirectory _Instance;
        public static CurrentDirectory GetIntstance()
        {
            if (_Instance == null)
                _Instance = new CurrentDirectory();

            return _Instance;
        }

        public Dictionary<string, string> OpenedDictory =
            new Dictionary<string, string>();

        void LoadDirectoryList()
        {
            BinaryFormatter bf = new BinaryFormatter();

            FileStream file = File.Open(Environment.CurrentDirectory + "/CurrentDictory.dat"
                , FileMode.OpenOrCreate);

            _Instance = (CurrentDirectory)bf.Deserialize(file);
            file.Close();
        }

        void SaveDirectoryList()
        {
            BinaryFormatter bf = new BinaryFormatter();

            FileStream file = File.Create(
                Environment.CurrentDirectory + "/CurrentDictory.dat");

            //저장할 내용 입력

            bf.Serialize(file, _Instance);
            file.Close();
        }

        public void LoadAllXml(string FilePath)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(FilePath);

            //BattleField_Container Create
            BattleField_Container BattleField = new BattleField_Container();
            string FieldName = "";
            XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("/Field");
            foreach (XmlNode node in nodeList)
            {
                BattleField_Container.LoadXML_BFContainer(
                    BattleField, node, out FieldName);
            }

            //MonsterStat Create
            string MonsterName = "";
            nodeList = xmlDoc.DocumentElement.SelectNodes("/Field/Monster");
            foreach (XmlNode node in nodeList)
            {
                MonsterStat MonsterElement = MonsterStat.LoadXML_MonsterElement(node, out MonsterName);
                BattleField.MonsterStatContainer.Add(
                    MonsterName, MonsterElement);
            }

            Form1._FieldContainer.Add(FieldName, BattleField);
        }
    }
}
