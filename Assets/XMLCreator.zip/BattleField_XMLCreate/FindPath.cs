﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace BattleField_XMLCreate
{
    public partial class FindPath : Form
    {
        public FindPath()
        {
            InitializeComponent();
        }

        private void FindPath_Load(object sender, EventArgs e)
        {
            OpenedFileListView.View = View.Details;
            OpenedFileListView.Columns.Add("OpenedFileDictory", 265);
            OpenedFileListView.Columns.Add("OpenedFileName", 100);

            ApplyOpenedView();
        }

        private void ApplyOpenedView()
        {
            Dictionary<string, string> diectoryDic =
                CurrentDirectory.GetIntstance().OpenedDictory;

            for (int i = 0; i < diectoryDic.Count; ++i)
            {
                ListViewItem item = new ListViewItem(diectoryDic.Keys.ToList()[i]);
                item.SubItems.Add(diectoryDic.Values.ToList()[i]);

                OpenedFileListView.Items.Add(item);
            }
        }

        private void DetailDirectory_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.ShowDialog();

            string FilePath = dlg.FileName;
            CurrentDirectory.GetIntstance().OpenedDictory.Add(Mecro.SeperateFileName(FilePath), FilePath);
        }

        private void SaveXML_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            
            dlg.ShowDialog();
            dlg.Title = "Save Battle Field xml";
            dlg.DefaultExt = "xml";
            dlg.Filter = "XML File(*.xml) |*.xml| All File(*.)|*.*";
            dlg.FilterIndex = 2;

            

            CreateXML(dlg.FileName);
        }

        private void CreateXML(string FullPath)
        {
            int filetypeidx = FullPath.LastIndexOf('.');
            string fileFilterString = FullPath.Substring(filetypeidx + 1);
            string xmlfileName = Mecro.SeperateFileName(FullPath);

            if(fileFilterString != "xml")
            {
                MessageBox.Show(fileFilterString + " - 지원하지 않는 형식입니다.");
                return;
            }

            XmlTextWriter writer = new XmlTextWriter(xmlfileName, Encoding.UTF8);
            writer.WriteStartDocument(true);
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;

            Dictionary<string, BattleField_Container> writeContainer
                = Form1._FieldContainer;

            for (int i = 0; i < writeContainer.Count; ++i)
            {
                writer = writeContainer.Values.ToList()[i].WriteXML_BFContainer(writer);
            }

            writer.WriteEndDocument();
            writer.Close();
        }

        private void LoadXML_Click(object sender, EventArgs e)
        {

        }

       
    }
}
