﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BattleField_XMLCreate
{
    public class BattleField_Container
    {
        private string _FieldName;
        public string FieldName
        {
            get { return _FieldName; }
            set { _FieldName = value; }
        }

        private int _RequireLevel;
        public int RequireLevel
        {
            get { return _RequireLevel; }
            set { _RequireLevel = value; }
        }

        public Dictionary<string, MonsterStat> MonsterStatContainer
            = new Dictionary<string, MonsterStat>();

        public XmlTextWriter WriteXML_BFContainer(XmlTextWriter writer)
        {
            writer.WriteStartElement("Field");

            writer.WriteStartElement("FieldName");
            writer.WriteString(_FieldName);
            writer.WriteEndElement();

            writer.WriteStartElement("RequireLevel");
            writer.WriteString(_RequireLevel.ToString());
            writer.WriteEndElement();

            for (int i = 0; i < MonsterStatContainer.Count; ++i)
                MonsterStatContainer.Values.ToList()[i].WriteXML_MonsterElement(writer);

            writer.WriteEndElement();

            return writer;
        }
        public static void LoadXML_BFContainer(
            BattleField_Container container,
            XmlNode node, out string FieldName)
        {
            container.FieldName = node.SelectSingleNode("FieldName").InnerText;
            container.RequireLevel = int.Parse(node.SelectSingleNode("RequireLevel").InnerText);

            FieldName = container.FieldName;
        }
    }
}
