﻿using UnityEngine;
using System.Collections;

public class BackGroundManager : MonoBehaviour {

    [SerializeField]    private GameObject obj1;
    [SerializeField]    private GameObject obj2;

    // Use this for initialization
    void Start () {
	    
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
