﻿using UnityEngine;
using System.Collections;

public class Battle_NGUI_EventMsgManager : 
    Singleton<Battle_NGUI_EventMsgManager>{

    void Awake()
    {
        CreateInstance();
    }

    public void DestroyAllEventMessage()
    {
        transform.DestroyChildren();
    }
}
