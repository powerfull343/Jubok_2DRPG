﻿using UnityEngine;
using System.Collections;

public class NGUI_ItemDropObjects : MonoBehaviour {


}
